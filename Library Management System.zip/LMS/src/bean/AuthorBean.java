package bean;

public class AuthorBean {
	private int authorCode;
	private String authorName;
	private long contactNumber;
	public int getAuthorCode() {
		return authorCode;
	}
	public void setAuthorCode(int authorCode) {
		this.authorCode = authorCode;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}
	
}
