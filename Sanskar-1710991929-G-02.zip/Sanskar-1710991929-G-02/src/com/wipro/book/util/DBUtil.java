package com.wipro.book.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtil {
	
	public static Connection getDBConnection() {
		String uname="system";
		String pass="apple123";
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn  = DriverManager.getConnection("jdbc:oracle:thin:@orcl.rmk.ac.in:1521:ORCL",uname,pass);
			return conn;
		}
		catch(Exception e){
			System.out.println("Exception"+e);
			
		}
		return null;
	}
	
}
